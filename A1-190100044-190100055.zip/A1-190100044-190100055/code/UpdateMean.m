function newMean = UpdateMean (OldMean, NewDataValue, n)
    newMean = OldMean + NewDataValue/n;
end